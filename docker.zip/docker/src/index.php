<?php

echo "Hello, world";